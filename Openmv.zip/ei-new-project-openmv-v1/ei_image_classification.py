# Edge Impulse - OpenMV Image Classification Example

import sensor, image, time, os, tf, uos, gc, pyb, math

sensor.reset()                         # Reset and initialize the sensor.
sensor.set_pixformat(sensor.RGB565)    # Set pixel format to RGB565 (or GRAYSCALE)
sensor.set_framesize(sensor.QVGA)      # Set frame size to QVGA (320x240)
sensor.set_windowing((240, 240))       # Set 240x240 window.
sensor.skip_frames(time=2000)          # Let the camera adjust.

net = None
labels = None

try:
    # load the model, alloc the model file on the heap if we have at least 64K free after loading
    net = tf.load("trained.tflite", load_to_fb=uos.stat('trained.tflite')[6] > (gc.mem_free() - (64*1024)))
except Exception as e:
    print(e)
    raise Exception('Failed to load "trained.tflite", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')

try:
    labels = [line.rstrip('\n') for line in open("labels.txt")]
except Exception as e:
    raise Exception('Failed to load "labels.txt", did you copy the .tflite and labels.txt file onto the mass-storage device? (' + str(e) + ')')

clock = time.clock()

############    Mycode     ##############
Flag = 0

led = pyb.LED(1)

from pyb import UART
import struct
uart3 = UART(3,115200)
uart3.init(115200, bits=8, parity=None, stop=1)

#发送->stm32
def Uart_TX(res):
    data=bytearray([0x2C,0x03,res,0x5B])
    #data = bytearray([0x01])
    uart3.write(data)
    #print(data)

#接收<-stm32
#b'1' <- 0x31
#b'2' <- 0x32
def Uart_RX():
    global Flag
    if uart3.any():
        #print(type(uart3.any()))
        res = uart3.read(1)#OpenMV直接接收字符文本类型 转为tytes类
        print(res)
        if(res == b'1'):
            led.on()
            Flag = 1;
        else:
            Flag = 0;
        #if(res == b'2'):
            #led.off()

############################################

while(True):
    clock.tick()
    img = sensor.snapshot()

    if(Flag == 1):#
        # default settings just do one detection... change them to search the image...
        for obj in net.classify(img, min_scale=1.0, scale_mul=0.8, x_overlap=0.5, y_overlap=0.5):
            print("**********\nPredictions at [x=%d,y=%d,w=%d,h=%d]" % obj.rect())
            img.draw_rectangle(obj.rect())
            # This combines the labels and confidence values into a list of tuples
            predictions_list = list(zip(labels, obj.output()))

            res = [0,0,0]

            for i in range(len(predictions_list)):
                print("%s = %f" % (predictions_list[i][0], predictions_list[i][1]))
                res[i] = predictions_list[i][1]

            for i in range(3):
                if res[i] == max(res):
                    print(i+1)###
                    Uart_TX(i+1)

        Flag = 0
        pyb.delay(500)
    Uart_RX()
    #print(clock.fps(), "fps")









